//
//  UIAlertController+supportedInterfaceOrientations.h
//
//
//  Created by lbxia on 16/1/16.
//  Copyright © 2016年 lbxia. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIAlertController (supportedInterfaceOrientations)

@end
