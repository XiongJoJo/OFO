//
//  LBXScanBaseViewController.h
//  LBXScanDemo
//
//  Created by lbxia on 2017/4/25.
//  Copyright © 2017年 lbx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LBXScanBaseViewController : UIViewController

@end
